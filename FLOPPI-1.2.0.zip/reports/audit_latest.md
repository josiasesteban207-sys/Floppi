# FLOPPI Audit Report 1.2.0

- Generated: 2026-11-01T05:24:26.202377+00:00
- Python: `3.10.0`
- Automated check pass rate: **100.0%** (12/12)

> This automated pass rate is not a production certification or a replacement for manual/security/integration review.

## Results

| Check | Status | Details |
|---|---|---|
| Project structure | **PASS** | All required files exist. |
| Compile application and worker | **PASS** |  |
| Pytest suite | **PASS** | ........................................................................ [ 69%] ................................                                         [100%] 104 passed in 7.03s |
| Indicator finite-input probe | **PASS** | SMA/EMA rejected or safely handled all non-finite probes. |
| Provider isolation (static heuristic) | **PASS** | Provider filter and memory-key references found. |
| Candle-gap validation (static heuristic) | **PASS** | Gap-related validation markers found. |
| Secret hygiene (static scan) | **PASS** | No high-confidence hard-coded secrets found; per-worker hash/expiry/RLS controls detected. .env files were not read; this is not a full secret scanner. |
| DEMO/simulation disclosure | **PASS** | README documents DEMO/simulation scope. |
| Monitoring history RLS (static check) | **PASS** | RLS remains enabled and table privileges are limited to the service role. |
| Diagnostic history RLS (static check) | **PASS** | Incident history uses unique fingerprints, deduplicated observations, enabled RLS, and server-role-only access. |
| Central event log RLS/privacy (static check) | **PASS** | Events have unique/correlation IDs, configurable retention, sensitive-key filtering, RLS, and service-role-only storage. |
| Task scheduler RLS/deduplication (static check) | **PASS** | Schedules use RLS/service-role grants, unique execution slots, bounded ownership, priority claims, and safe cancellation. |

## Test command output

### Compile application and worker (0.618 s)

```text

```

### Pytest suite (12.412 s)

```text
........................................................................ [ 69%]
................................                                         [100%]
104 passed in 7.03s
```

### Indicator finite-input probe (0.204 s)

```text
SMA/EMA rejected or safely handled all non-finite probes.
```

## Manual checks still required

- Real Supabase migrations, RLS, JWT isolation and worker RPC integration.
- External provider behavior and multi-provider reconciliation.
- Load, concurrency, p95/p99 latency, memory and recovery tests.
- Walk-forward/out-of-sample methodology review and strategy-overfit review.
- Review of deployment TLS, rate limits, backups and restore procedures.

## Comparison with previous audit

- Previous report: `2026-11-01T05:05:00.831087+00:00`
- Checks improved: 0
- Checks regressed: 0
- Checks unchanged: 11
