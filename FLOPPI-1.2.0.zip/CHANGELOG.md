# Changelog

## 1.2.0 - Central Task Scheduler

- Added persistent per-user schedules for repeatable historical DEMO backtests with validated existing data and fingerprints.
- Added priority ordering, per-schedule concurrency limits, configurable worker retry attempts, missed-interval skipping, and task execution history.
- Added an API-lifecycle scheduler that dispatches due tasks through a transaction-safe Supabase RPC or process-local DEMO storage.
- Added pause, resume, and safe cancellation; queued work is cancelled while already leased worker executions may finish.
- Added migration 013 with RLS enabled, service-role-only grants, due-task locking, unique schedule slots, and priority-aware worker claiming.
- Added Backtesting dashboard controls and scheduled-run history; no real financial operation or live market-data collection is enabled.

## 1.1.6 - Centralized Event Logging

- Added UTC-normalized operational events with unique IDs and request/task correlation.
- Captured sanitized API errors, observed database/storage/worker/queue/resource health events, and authenticated worker/task lifecycle events.
- Added development-only event search, severity/component/time filters, bounded pagination, and JSON/CSV exports.
- Added configurable event retention through `EVENT_LOG_RETENTION_DAYS` (default 30; allowed range 1-3650 days) with scheduled cleanup.
- Added migration 012 with RLS enabled, no anon/authenticated access, and service-role-only table/RPC privileges.
- Excluded request bodies, query strings, credentials, authorization headers, raw exception messages, and sensitive metadata.
- Integrated event history into the existing intelligent diagnostics dashboard; no financial operation or automatic repair was introduced.

## 1.1.5 - Intelligent Diagnostics

- Added persistent, fingerprint-grouped diagnostic incidents for observed API 5xx errors and real health-check signals from storage, workers, queue, and host resources.
- Deduplicated repeated health sampler runs in the same five-minute observation bucket while counting distinct API failures individually.
- Added severity, occurrence frequency, affected components, sanitized evidence, likely causes, safe recommendations, and manually recorded resolution notes.
- Automatically resolves health-derived incidents only after a healthy observation; API errors remain open until an operator reviews them.
- Added development-only incident summary/history, date and severity filters, CSV/JSON reports, and explicit manual resolution.
- Added migration 011 with RLS enabled, no anon/authenticated access, and service-role-only table/RPC privileges.
- Kept repairs manual and preserved the simulation-only/no-broker boundary.

## 1.1.4 - Historical System Statistics

- Added a FastAPI-lifecycle sampler that records idempotent system-health observations on five-minute UTC boundaries.
- Added Supabase-backed historical observations, with an in-memory DEMO fallback and a 90-day query limit.
- Added actual collection timestamps, API host CPU/RAM/disk/process observations, and overall/component health history.
- Added active/inactive/disconnected Blacki and Blanquita status counts and timelines, plus per-sample task-queue averages and maxima.
- Added 1-hour, 6-hour, 24-hour, 7-day, and 30-day dashboard filters, historical charts, and period-filtered JSON/CSV reports.
- Added migration 010 with RLS enabled, no anon/authenticated policies, and server-role-only table grants.
- Kept monitoring routes development-only until an administrator authorization model exists.
- Added validation for migration RLS/uniqueness and measured system statistics.
- Preserved the educational DEMO-only boundary; no broker or real-order integration.

## 1.0.0 - Experiment Lab & Reporting

- Promoted the API and web console release version to 1.0.0.
- Added a dashboard workflow to select 2-10 completed backtests and compare their saved metrics through the existing comparison API.
- Added downloadable JSON and CSV comparison reports with generation time, DEMO classification, and simulation-only disclaimer.
- Added responsive comparison layout and explicit handling for missing metric values.
- No database migration required; no worker protocol change.
- Kept all functionality educational and simulation-only.


## 0.7.1 - Web Console

- Added a responsive Spanish-first professional dashboard served by FastAPI.
- Added Overview, Market Analysis, Backtesting, Workers, and History views.
- Connected the UI to existing health, market, candle, indicator, hybrid-analysis, strategy, backtest, and development-only worker-list endpoints.
- Added synthetic DEMO dataset generation from the market explorer.
- Added historical close-price visualization using a lightweight local SVG chart.
- Preserved the backend API contract and worker credential flow from 0.7.0.
- Kept all workflows educational and simulation-only; no broker or real-order integration.

## 0.7.0

- Added individual worker credentials, hash storage, expiry, rotation, and revocation support.


## 0.8.0 - Distributed worker telemetry
- Added runtime metadata and busy/idle worker heartbeats.
- Added heartbeat thread so long-running backtests do not appear disconnected.
- Added derived offline status after 90 seconds and worker summary endpoint.
- Added Supabase migration 005 for telemetry columns and busy status.


## 0.9.0 - Reliable distributed jobs
- Added five-minute job leases with unique per-claim lease tokens.
- Added lease renewal while workers run long backtests.
- Added bounded retry behavior with exponential backoff and terminal failure after the attempt limit.
- Added recovery of expired worker leases and protection against stale workers completing reclaimed jobs.
- Added Supabase migration 006 with server-only RPC permissions.
- Preserved DEMO-only backtesting and the existing professional web console.

## 1.1.1 - Performance Metrics & System Health

- Added point-in-time CPU, memory, disk, and API-process memory observations for the API host.
- Added worker resource telemetry to authenticated heartbeats; metrics are validated and stored with collection timestamps.
- Added development-only performance and system-health report endpoints.
- Added dashboard view for API resources, per-worker metrics, component health, and JSON/CSV health exports.
- Added Supabase migration 007 for worker resource metric snapshots; existing server-managed access model is preserved.
- Metrics are snapshots, not historical trends, synthetic values, or hardware benchmarks.
- Kept FLOPPI educational and DEMO-only.
