# FLOPPI Audit Report 1.3.2.2

- Generated: 2026-11-02T17:33:28.424879+00:00
- Python: `3.10.0`
- Automated check pass rate: **100.0%** (17/17)

> This automated pass rate is not a production certification or a replacement for manual/security/integration review.

## Results

| Check | Status | Details |
|---|---|---|
| Project structure | **PASS** | All required files exist. |
| Compile application and worker | **PASS** |  |
| Pytest suite | **PASS** | ........................................................................ [ 44%] ........................................................................ [ 88%] ..................                                                       [100%] 162 passed in 7.22s |
| Indicator finite-input probe | **PASS** | SMA/EMA rejected or safely handled all non-finite probes. |
| Provider isolation (static heuristic) | **PASS** | Provider filter and memory-key references found. |
| Candle-gap validation (static heuristic) | **PASS** | Gap-related validation markers found. |
| Secret hygiene (static scan) | **PASS** | No high-confidence hard-coded secrets found; per-worker hash/expiry/RLS controls detected. .env files were not read; this is not a full secret scanner. |
| DEMO/simulation disclosure | **PASS** | README documents DEMO/simulation scope. |
| Security Core controls (static check) | **PASS** | Verified admin metadata, mutation auditing, expiring worker tokens, browser-only public Auth, safe worker errors, and loopback Compose binding. |
| Staging isolation (static configuration) | **PASS** | No host ports, internal-only network, dedicated storage, private settings and no Supabase target are configured; runtime connectivity is checked separately. |
| Monitoring history RLS (static check) | **PASS** | RLS remains enabled and table privileges are limited to the service role. |
| Diagnostic history RLS (static check) | **PASS** | Incident history uses unique fingerprints, deduplicated observations, enabled RLS, and server-role-only access. |
| Central event log RLS/privacy (static check) | **PASS** | Events have unique/correlation IDs, configurable retention, sensitive-key filtering, RLS, and service-role-only storage. |
| Task scheduler RLS/deduplication (static check) | **PASS** | Schedules use RLS/service-role grants, unique execution slots, bounded ownership, priority claims, and safe cancellation. |
| Worker load balancing/RPC access (static check) | **PASS** | Claims use fresh resource/heartbeat observations, task history, one-job capacity, row locking, and service-role-only RPC access. |
| Expired worker lease recovery/access (static check) | **PASS** | Recovery is bounded/idempotent, uses row locking and retry backoff, and exposes its RPC only to service_role. |
| Hybrid signal history RLS/deduplication (static check) | **PASS** | Point-in-time signals use unique timestamps, completed-outcome updates, RLS, and service-role-only storage. |

## Test command output

### Compile application and worker (0.646 s)

```text

```

### Pytest suite (11.162 s)

```text
........................................................................ [ 44%]
........................................................................ [ 88%]
..................                                                       [100%]
162 passed in 7.22s
```

### Indicator finite-input probe (0.315 s)

```text
SMA/EMA rejected or safely handled all non-finite probes.
```

## Manual checks still required

- Real Supabase migrations, RLS, JWT isolation and worker RPC integration.
- Separate Supabase staging project, Auth/RLS/RPC isolation, and execution of migration 017.
- External provider behavior and multi-provider reconciliation.
- Load, concurrency, p95/p99 latency, memory and recovery tests.
- Walk-forward/out-of-sample methodology review and strategy-overfit review.
- Review of deployment TLS, rate limits, backups and restore procedures.

## Comparison with previous audit

- Previous report: `2026-11-02T17:25:57.468010+00:00`
- Checks improved: 0
- Checks regressed: 0
- Checks unchanged: 17
