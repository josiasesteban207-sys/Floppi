import asyncio
import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from app.settings import settings
from app.api.routes import router
from app.api.data_routes import router as data_router
from app.api.analysis_routes import router as analysis_router
from app.api.backtesting_routes import router as backtesting_router
from app.api.monitoring_routes import router as monitoring_router, run_monitoring_sampler
from app.api.diagnostics_routes import router as diagnostics_router
from app.diagnostics import diagnostic_repository, record_api_failure

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    sampler = asyncio.create_task(run_monitoring_sampler(), name="monitoring-history-sampler")
    try:
        yield
    finally:
        sampler.cancel()
        try:
            await sampler
        except asyncio.CancelledError:
            pass

app = FastAPI(
    title="FLOPPI API",
    version="1.1.5",
    description="Hybrid educational market-analysis platform. Simulation only.",
    lifespan=lifespan,
)

origins = [item.strip() for item in settings.cors_origins.split(",") if item.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins or [],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT"],
    allow_headers=["Authorization", "Content-Type", "X-Node-Token", "X-Node-Id", "X-Job-Lease-Token"],
)

app.include_router(router, prefix="/api/v1")
app.include_router(data_router, prefix="/api/v1")
app.include_router(analysis_router, prefix="/api/v1")
app.include_router(backtesting_router, prefix="/api/v1")
app.include_router(monitoring_router, prefix="/api/v1")
app.include_router(diagnostics_router, prefix="/api/v1")


async def _record_api_failure(status_code: int, method: str, error_type: str | None = None) -> None:
    try:
        await asyncio.to_thread(
            record_api_failure,
            diagnostic_repository,
            status_code=status_code,
            method=method,
            error_type=error_type,
        )
    except Exception:
        logger.exception("Could not record API diagnostic incident")


@app.middleware("http")
async def observe_api_failures(request, call_next):
    is_api_request = request.url.path.startswith("/api/v1/")
    try:
        response = await call_next(request)
    except Exception as exc:
        if is_api_request:
            await _record_api_failure(500, request.method, type(exc).__name__)
        raise
    if is_api_request and response.status_code >= 500:
        await _record_api_failure(response.status_code, request.method)
    return response

STATIC_DIR = Path(__file__).resolve().parent / "static"
app.mount("/assets", StaticFiles(directory=STATIC_DIR), name="assets")

@app.get("/", include_in_schema=False)
def root():
    return FileResponse(STATIC_DIR / "index.html")
