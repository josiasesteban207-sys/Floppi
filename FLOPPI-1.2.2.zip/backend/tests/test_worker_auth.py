import hashlib
from datetime import datetime, timedelta, timezone

import pytest
from fastapi import HTTPException

from app.api import worker_auth


class FakeResponse:
    def __init__(self, data):
        self.data = data


class FakeQuery:
    def __init__(self, record):
        self.record = record
        self.filters = {}
        self.operation = "select"
        self.updated = None

    def select(self, _columns):
        self.operation = "select"
        return self

    def update(self, payload):
        self.operation = "update"
        self.updated = payload
        return self

    def eq(self, key, value):
        self.filters[key] = value
        return self

    def limit(self, _count):
        return self

    def execute(self):
        if self.operation == "update":
            return FakeResponse([self.updated])
        if (
            self.record
            and self.filters.get("token_hash") == self.record["token_hash"]
            and self.filters.get("active") is self.record["active"]
        ):
            return FakeResponse([self.record])
        return FakeResponse([])


class FakeSupabase:
    def __init__(self, record):
        self.query = FakeQuery(record)

    def table(self, name):
        assert name == "worker_credentials"
        return self.query


def test_database_worker_token_is_hashed_bound_and_usage_is_recorded(monkeypatch):
    token = "a-unique-worker-token-that-is-long-enough-123"
    record = {
        "id": "credential-1",
        "node_id": "node-a",
        "token_hash": hashlib.sha256(token.encode()).hexdigest(),
        "active": True,
        "expires_at": (datetime.now(timezone.utc) + timedelta(days=2)).isoformat(),
    }
    client = FakeSupabase(record)
    monkeypatch.setattr(worker_auth, "get_supabase", lambda: client)

    assert worker_auth.verify_node(token, "node-a") == "node-a"
    assert client.query.updated is not None
    assert "last_used_at" in client.query.updated


def test_database_worker_token_rejects_wrong_node(monkeypatch):
    token = "a-unique-worker-token-that-is-long-enough-123"
    record = {
        "id": "credential-1",
        "node_id": "node-a",
        "token_hash": hashlib.sha256(token.encode()).hexdigest(),
        "active": True,
        "expires_at": None,
    }
    monkeypatch.setattr(worker_auth, "get_supabase", lambda: FakeSupabase(record))

    with pytest.raises(HTTPException) as error:
        worker_auth.verify_node(token, "node-b")
    assert error.value.status_code == 401


def test_database_worker_token_rejects_expired_credential(monkeypatch):
    token = "a-unique-worker-token-that-is-long-enough-123"
    record = {
        "id": "credential-1",
        "node_id": "node-a",
        "token_hash": hashlib.sha256(token.encode()).hexdigest(),
        "active": True,
        "expires_at": (datetime.now(timezone.utc) - timedelta(seconds=1)).isoformat(),
    }
    monkeypatch.setattr(worker_auth, "get_supabase", lambda: FakeSupabase(record))

    with pytest.raises(HTTPException) as error:
        worker_auth.verify_node(token, "node-a")
    assert error.value.status_code == 401


def test_database_worker_token_rejects_revoked_credential(monkeypatch):
    token = "a-unique-worker-token-that-is-long-enough-123"
    record = {
        "id": "credential-1",
        "node_id": "node-a",
        "token_hash": hashlib.sha256(token.encode()).hexdigest(),
        "active": False,
        "expires_at": None,
    }
    monkeypatch.setattr(worker_auth, "get_supabase", lambda: FakeSupabase(record))

    with pytest.raises(HTTPException) as error:
        worker_auth.verify_node(token, "node-a")
    assert error.value.status_code == 401
