"""Market data provider adapters."""
