from uuid import UUID

from fastapi import APIRouter, HTTPException, Query

from app.analysis.technical_engine import analyze, calculate_indicators
from app.data.models import Candle, Timeframe
from app.data.repository import market_repository

router = APIRouter()


def _load_candles(asset_id: UUID, timeframe: Timeframe, limit: int) -> list[Candle]:
    records = market_repository.list_candles(asset_id, timeframe, limit=limit)
    if not records:
        raise HTTPException(status_code=404, detail="No historical candles are available for this asset and timeframe.")
    return [Candle.model_validate(record) for record in records]


@router.get("/analysis/indicators")
def indicators(
    asset_id: UUID,
    timeframe: Timeframe,
    limit: int = Query(default=500, ge=1, le=2000),
):
    candles = _load_candles(asset_id, timeframe, limit)
    return {
        "timestamps": [candle.close_time.isoformat() for candle in candles],
        "indicators": calculate_indicators(candles),
        "sample_size": len(candles),
        "data_kind": "DEMO",
    }


@router.get("/analysis/technical")
def technical_analysis(
    asset_id: UUID,
    timeframe: Timeframe,
    limit: int = Query(default=500, ge=1, le=2000),
):
    result = analyze(_load_candles(asset_id, timeframe, limit))
    result["data_kind"] = "DEMO"
    return result


@router.get("/analysis/history")
def analysis_history(
    asset_id: UUID,
    timeframe: Timeframe,
    limit: int = Query(default=500, ge=1, le=2000),
):
    candles = _load_candles(asset_id, timeframe, limit)
    return {
        "asset_id": str(asset_id),
        "timeframe": timeframe,
        "timestamps": [candle.close_time.isoformat() for candle in candles],
        "indicators": calculate_indicators(candles),
        "data_kind": "DEMO",
    }


@router.get("/analysis/hybrid")
def hybrid_analysis(
    asset_id: UUID,
    timeframe: Timeframe,
    limit: int = Query(default=500, ge=1, le=2000),
):
    """Return explainable method-family consensus for historical DEMO data."""
    result = analyze(_load_candles(asset_id, timeframe, limit))
    return {
        "asset_id": str(asset_id),
        "timeframe": timeframe,
        "sample_size": result["sample_size"],
        "summary": result["summary"],
        "data_kind": "DEMO",
        "scope": "descriptive_analysis_only",
    }
