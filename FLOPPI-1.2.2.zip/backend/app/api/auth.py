import logging

import httpx
from fastapi import Header, HTTPException
try:
    from supabase_auth.errors import AuthApiError
except ImportError:
    try:
        from gotrue.errors import AuthApiError
    except ImportError:
        class AuthApiError(Exception):
            status = 401

from app.settings import settings
from app.supabase_store import get_supabase

logger = logging.getLogger(__name__)


def optional_user_id(authorization: str | None = Header(default=None)) -> str | None:
    if not authorization:
        if settings.app_env.casefold() == "development":
            return None
        raise HTTPException(status_code=401, detail="A valid Supabase access token is required.")

    scheme, separator, token = authorization.partition(" ")
    if not separator or scheme.casefold() != "bearer" or not token.strip():
        raise HTTPException(status_code=401, detail="A valid Supabase bearer token is required.")

    client = get_supabase()
    if client is None:
        raise HTTPException(status_code=503, detail="Authentication is unavailable.")
    try:
        response = client.auth.get_user(token.strip())
    except AuthApiError as exc:
        logger.warning("Supabase JWT validation failed (%s).", type(exc).__name__)
        if exc.status >= 500:
            raise HTTPException(status_code=503, detail="Authentication service is unavailable.") from exc
        raise HTTPException(status_code=401, detail="Invalid or expired access token.") from exc
    except httpx.HTTPError as exc:
        logger.warning("Supabase JWT validation is unavailable (%s).", type(exc).__name__)
        raise HTTPException(status_code=503, detail="Authentication service is unavailable.") from exc

    user = getattr(response, "user", None)
    if user is None or not getattr(user, "id", None):
        raise HTTPException(status_code=401, detail="Invalid or expired access token.")
    return str(user.id)
