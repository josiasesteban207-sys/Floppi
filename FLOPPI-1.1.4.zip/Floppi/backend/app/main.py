import asyncio
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from app.settings import settings
from app.api.routes import router
from app.api.data_routes import router as data_router
from app.api.analysis_routes import router as analysis_router
from app.api.backtesting_routes import router as backtesting_router
from app.api.monitoring_routes import router as monitoring_router, run_monitoring_sampler


@asynccontextmanager
async def lifespan(app: FastAPI):
    sampler = asyncio.create_task(run_monitoring_sampler(), name="monitoring-history-sampler")
    try:
        yield
    finally:
        sampler.cancel()
        try:
            await sampler
        except asyncio.CancelledError:
            pass

app = FastAPI(
    title="FLOPPI API",
    version="1.1.4",
    description="Hybrid educational market-analysis platform. Simulation only.",
    lifespan=lifespan,
)

origins = [item.strip() for item in settings.cors_origins.split(",") if item.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins or [],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT"],
    allow_headers=["Authorization", "Content-Type", "X-Node-Token", "X-Node-Id", "X-Job-Lease-Token"],
)

app.include_router(router, prefix="/api/v1")
app.include_router(data_router, prefix="/api/v1")
app.include_router(analysis_router, prefix="/api/v1")
app.include_router(backtesting_router, prefix="/api/v1")
app.include_router(monitoring_router, prefix="/api/v1")

STATIC_DIR = Path(__file__).resolve().parent / "static"
app.mount("/assets", StaticFiles(directory=STATIC_DIR), name="assets")

@app.get("/", include_in_schema=False)
def root():
    return FileResponse(STATIC_DIR / "index.html")
