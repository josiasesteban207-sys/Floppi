# FLOPPI 1.1.4

FLOPPI is an educational historical-market analysis and paper-backtesting
platform. The synthetic provider is always labeled `DEMO`; this project does
not place real orders, connect to brokers, or manage funds.

## What is implemented

- Experiment comparison in the web console for 2-10 completed backtests, using the existing authenticated comparison endpoint.
- Export of comparison results as JSON or CSV, including a DEMO label and historical-simulation disclaimer.
- Point-in-time API host and worker CPU/RAM/disk observations, system health snapshots, and JSON/CSV health reports.
- Persistent five-minute system-health observations, historical state distributions, Blacki/Blanquita observed availability, queue averages/maxima, period filters, and CSV/JSON exports.

- Supabase PostgreSQL migrations for nodes, multimarket assets/candles, data
  quality, strategies, backtest jobs, trades, and metrics, including a provider-scoped candle index.
- OHLCV validation and deterministic, timestamp-stable synthetic demo data.
- SMA, EMA, RSI, MACD, Bollinger Bands, ATR, and cumulative VWAP with explicit
  rejection of NaN and infinite inputs.
- Explainable hybrid engine that groups SMA/EMA as trend, MACD/RSI as momentum,
  and price/VWAP as price-volume confirmation; reports internal and cross-family
  disagreement, evidence coverage, volatility context, and abstains when evidence is thin.
- SMA-cross, RSI, and MACD long-only example strategies.
- A persistent Supabase job queue claimed by the local worker; the API does not
  execute backtests in the cloud.
- Virtual portfolio accounting, fees, slippage, drawdown, return, trade,
  profit-factor, and Sharpe metrics.
- Supabase Auth access-token validation and per-user filtering for strategy and backtest API
  operations. Public market-history reads contain no user data.


## Web dashboard (1.1.4)

FLOPPI now serves a responsive web console from the FastAPI application. Start the API using the command above, then open `http://127.0.0.1:8000/`. The dashboard includes:

- Overview of API/storage health, catalog assets, candle counts, worker status, and recent backtests.
- Market explorer with synthetic DEMO dataset generation, historical close-price chart, hybrid evidence summary, and indicator readings.
- Backtest queue form using the existing strategy and worker queue endpoints.
- Worker status view (node listing remains development-only) and credential setup guidance.
- Performance and health view with host resources, per-worker resource snapshots, component health, and report exports.
- Historical health statistics by 1-hour, 6-hour, 24-hour, 7-day, or 30-day periods, including state distributions, worker availability, resource charts, and queue observations.
- Backtest history and links to the API documentation.

The web console uses the existing API and does not expose worker credentials or the Supabase service-role key. The dashboard is served from the same origin as the API.

## Set up Supabase

1. Copy `.env.example` to `.env`.
2. Set `SUPABASE_URL` and the server-side `SUPABASE_SERVICE_ROLE_KEY`. Never
   place this key in a client app or commit it.
3. In the Supabase SQL Editor, apply migrations in order:
   [001_initial.sql](./database/migrations/001_initial.sql),
   [002_multimarket_backtesting.sql](./database/migrations/002_multimarket_backtesting.sql),
   [003_provider_scoped_candle_index.sql](./database/migrations/003_provider_scoped_candle_index.sql),
   and [004_worker_credentials.sql](./database/migrations/004_worker_credentials.sql), then [005_distributed_worker_telemetry.sql](./database/migrations/005_distributed_worker_telemetry.sql), [006_reliable_job_leases.sql](./database/migrations/006_reliable_job_leases.sql), [007_worker_resource_metrics.sql](./database/migrations/007_worker_resource_metrics.sql), and [010_system_health_history.sql](./database/migrations/010_system_health_history.sql).
   If migrations 001-007 are already applied, apply migration 010. This checkout does not contain migrations 008 or 009; do not invent or apply placeholder migrations for them.
4. Create an individual credential for each worker. Generate a one-time token and SQL hash with:

   ```powershell
   python tools\provision_worker.py --node-id main-pc --expires-in-days 90
   ```

   Copy the generated SQL into the Supabase SQL Editor. The raw token is shown
   only once; the database stores its SHA-256 hash, never the token itself.
5. In Supabase project authentication, create normal user accounts for API
   clients. Send each user's Supabase access token as a `Bearer` token for
   strategy, data-collection, and backtest operations.

The API uses the service-role key server-side and therefore explicitly verifies
user access tokens and filters user-owned rows. Each worker uses a distinct random
credential; only its SHA-256 hash is stored in `worker_credentials`. Production
startup requires Supabase credentials and exact HTTPS CORS origins.

## Install and run (PowerShell)

From the project directory:

```powershell
py -3.10 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements-dev.txt
Copy-Item .env.example .env
uvicorn app.main:app --app-dir backend --host 127.0.0.1 --port 8000 --reload
```

Open `http://127.0.0.1:8000/docs`. `/api/v1/health` reports storage status. The development-only `/api/v1/monitoring/health`, `/api/v1/monitoring/performance`, and `/api/v1/monitoring/statistics` endpoints feed the Rendimiento y salud page. Historical exports are available from `/api/v1/monitoring/statistics/export?format=json` or `?format=csv`; both accept optional timezone-aware `start_at` and `end_at` filters, up to 90 days.
Without Supabase credentials the app uses process-local demo storage in
development; data, queued work, and monitoring history are lost when that process stops. The sampler records one observation every five minutes and aligns samples to UTC five-minute boundaries. Multiple API instances use the same unique time bucket to avoid duplicate observations.

## Run the local worker

In another PowerShell terminal, set the node-specific token generated for this
worker. Never reuse another node's token:

```powershell
$env:FLOPPI_API_URL = "http://127.0.0.1:8000"
$env:FLOPPI_NODE_ID = "main-pc"
$env:FLOPPI_NODE_TOKEN = "<one-time token generated for main-pc>"
python worker\local_worker.py
```

The worker sends an outbound heartbeat, polls for one queued backtest, computes
it locally, and posts the result. For remote deployments set
`FLOPPI_API_URL` to the HTTPS API URL; no inbound port forwarding is required.
Abandoned jobs are eligible for reassignment after one hour.

## API workflow

- `GET /api/v1/markets`, `/assets`, `/candles`,
  `/providers/status`, `/data/quality`
- `POST /api/v1/data/collect` creates historical **DEMO** candles. The seeded
  sample asset IDs are available from `GET /api/v1/assets`.
- `GET /api/v1/analysis/indicators`, `/analysis/technical`,
  `/analysis/history`, `/analysis/hybrid`
- `GET/POST/PUT /api/v1/strategies`
- `POST /api/v1/backtesting/run` returns `202` and queues a local job;
  `GET /api/v1/backtesting/runs` and run subroutes retrieve status, trades,
  metrics, and comparisons.

Production strategy and backtest APIs require Supabase-authenticated access
tokens. Worker-only queue routes require `X-Node-Token` and `X-Node-Id`; the token must be active, unexpired, and registered to that exact node.
Backtests are limited to 5,000 candles and each account may have at most five pending runs. Jobs store a
fingerprint of their candles; a run fails rather than silently using candle
data changed after it was queued.

## Indicators and methodology

- SMA uses a rolling arithmetic mean; EMA seeds from an SMA and then uses
  `alpha = 2 / (period + 1)`.
- RSI uses Wilder smoothing; MACD uses EMA 12/26 with EMA 9 signal.
- Bollinger Bands use a rolling mean and population standard deviation;
  ATR uses Wilder smoothing of true range.
- VWAP is cumulative over the requested candle series; it does not infer
  session boundaries.
- The hybrid agreement score is a raw percentage of directional method-family
  votes. SMA/EMA count as one family; MACD/RSI count as one family. Price/VWAP
  provides a third family. ATR is context only. The score is not a probability,
  calibrated confidence estimate, or forecast. Internal family disagreement
  removes that family from directional voting; fewer than two directional families
  or an even split produces an abstention.
- Candle reads and in-memory keys are scoped by asset, provider, and timeframe.
  The default API history remains the seeded DEMO provider.
- Signals use data through a candle's close and are filled at the next candle
  open. The final open position is liquidated at the last close.
- Sharpe annualization is approximate and market/timeframe dependent; profit
  factor is undefined when there are no losing trades. Small samples and data
  gaps are explicitly reported.

These are historical descriptions and simulations, not predictions or
personalized financial recommendations.

## Tests

```powershell
python -m pytest
```

The tests cover API/auth boundaries, normalization, deterministic demo data,
indicator formulas, worker queue transitions, fees, and next-bar execution.
An actual Supabase deployment/worker connection still requires project
credentials and the migrations above; no live credentials are included here.

## Security and scope

The Supabase service-role key bypasses RLS and must remain server-only. Direct
client access is limited by the migration's RLS policies. Node listings and
the in-memory notification-preference demo routes remain development-only.
Before a public launch, add rate limiting, operational monitoring, backup and
restore drills, and automated credential-expiry monitoring. Revoke a worker by
setting its `active` flag to false and `revoked_at` to `now()` in Supabase; rotate
by provisioning a new token and then revoking the old credential.

There is no Telegram, Flutter client, external price provider, adaptive AI, or
real-money/broker functionality in this backend milestone.

## Repeatable project audit

FLOPPI includes a non-destructive local audit runner. From the project root:

```powershell
python tools/audit.py
```

It compiles the backend/worker, runs pytest, probes indicator handling of non-finite values, checks selected data-quality/security signals, and writes Markdown/JSON reports under `reports/`. Timestamped snapshots are retained in `reports/history/` for comparison across runs. See [docs/AUDIT_ENGINE.md](docs/AUDIT_ENGINE.md) for scope, limitations, and manual production gates.


## Walk-forward evaluation (0.6.0)

See `docs/WALK_FORWARD_0_6.md` for the chronological out-of-sample evaluation endpoint `POST /api/v1/backtesting/walk-forward`, its window constraints, and methodological limitations. Strategy parameters remain fixed in this release; no automatic parameter optimization is performed.

## Worker credentials (0.7.0)

See [docs/WORKER_SECURITY_0_7.md](docs/WORKER_SECURITY_0_7.md) for provisioning, rotation, revocation, and the development-only fallback.


## Distributed worker telemetry (0.8.0)

See [docs/DISTRIBUTED_WORKERS_0_8.md](docs/DISTRIBUTED_WORKERS_0_8.md). Workers report runtime metadata and busy/idle state through periodic heartbeats, including during long backtests. The development dashboard derives `offline` after 90 seconds without a heartbeat and exposes `/api/v1/nodes/summary`. Apply migration 005 after migrations 001-004. This is telemetry and task coordination for historical DEMO backtests, not live trading.


## Reliable distributed jobs (0.9.0)

Migration 006 adds bounded job attempts, five-minute worker leases, unique lease tokens, retry backoff, and lease-aware completion/failure RPCs. Workers renew their lease every 30 seconds while a backtest is running. A worker can complete, renew, or fail only a job carrying its current lease token. Retryable worker errors are requeued with a short exponential delay and stop after the configured attempt limit (default: three). Data-integrity failures are terminal and are not retried.

Apply migration 006 after 005 before deploying this release. The automated suite exercises in-memory lease ownership and retry behavior; it does not substitute for testing the SQL functions against your own Supabase project. Keep RLS enabled and never expose the service-role key or node tokens to the browser.


## Experiment Lab & Reporting (1.0.0)

Open **Historial e informes** in the web console. Select between two and ten completed backtests, choose **Comparar resultados**, and export the comparison as JSON or CSV. The comparison uses metrics already persisted by the backtesting workflow; it does not optimize strategies, forecast future returns, or create investment recommendations. Missing or undefined metrics are displayed as unavailable rather than converted to zero.

This release requires no new Supabase migration and does not change the worker protocol. Existing migrations through 006 remain the deployment baseline.


## Performance metrics and system health (1.1.1)

Apply migration 007 after migrations 001-006, then update the API and workers to 1.1.1. Workers include CPU, RAM, disk, and worker-process memory observations in their authenticated heartbeat. The API exposes its own host/process snapshot and a component health report. These are point-in-time observations, not benchmark scores or historical trends. Missing metrics remain unavailable. See [docs/PERFORMANCE_AND_HEALTH_1_1_1.md](docs/PERFORMANCE_AND_HEALTH_1_1_1.md) for upgrade steps, endpoint details, interpretation, and limitations.

## Historical system statistics (1.1.4)

Apply migration 010 after all migrations present in this checkout (001-007), then update the API and workers to 1.1.4. The API records health, API host resources, component, worker, and task-queue observations every five minutes. The dashboard compares state distributions and Blacki/Blanquita active, inactive, and disconnected observations over 1-hour, 6-hour, 24-hour, 7-day, or 30-day windows. Resource charts, worker history, and CSV/JSON reports use persisted observations only. Queue values are averages and maxima per sample, not counts of unique tasks. The statistics endpoints remain development-only because this project does not yet have an administrator role/authorization model.

RLS remains enabled on `system_health_observations`, with no client-facing policies; only the backend service role receives table privileges. In-memory DEMO mode is not persistent and its history is lost on restart. The sampler is process-lifecycle-bound; it stops when the API stops. Observed availability is not continuous uptime or an SLA.

### Upgrade from 1.1.1

1. Back up the project and keep `.env` private.
2. Activate a Python 3.10 environment and install `pip install -r requirements-dev.txt`.
3. Apply `database/migrations/010_system_health_history.sql` using a Supabase admin connection after migrations 001-007.
4. Update the API and workers to 1.1.4, then restart them.
5. Open **Rendimiento y salud**, choose a period, and allow the sampler to collect observations. The first sample is recorded at startup; later samples align to five-minute UTC boundaries.
6. Export a JSON or CSV summary from the same panel.

The repository versions itself as 1.1.1 before this requested 1.1.4 milestone. Migrations 008 and 009 are not present in the checkout; migration 010 is designed to apply after 007 and does not depend on either missing file.
